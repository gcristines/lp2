﻿
namespace PAtividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnBrancos = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepetidas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(175, 46);
            this.rchtxtTexto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rchtxtTexto.MaxLength = 100;
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(508, 111);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnBrancos
            // 
            this.btnBrancos.Location = new System.Drawing.Point(191, 225);
            this.btnBrancos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBrancos.Name = "btnBrancos";
            this.btnBrancos.Size = new System.Drawing.Size(129, 27);
            this.btnBrancos.TabIndex = 1;
            this.btnBrancos.Text = "Espaços em Branco";
            this.btnBrancos.UseVisualStyleBackColor = true;
            this.btnBrancos.Click += new System.EventHandler(this.btnBrancos_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(387, 224);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(87, 28);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letra R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepetidas
            // 
            this.btnRepetidas.Location = new System.Drawing.Point(546, 222);
            this.btnRepetidas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRepetidas.Name = "btnRepetidas";
            this.btnRepetidas.Size = new System.Drawing.Size(117, 30);
            this.btnRepetidas.TabIndex = 3;
            this.btnRepetidas.Text = "Letras Repetidas";
            this.btnRepetidas.UseVisualStyleBackColor = true;
            this.btnRepetidas.Click += new System.EventHandler(this.btnRepetidas_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 328);
            this.Controls.Add(this.btnRepetidas);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnBrancos);
            this.Controls.Add(this.rchtxtTexto);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnBrancos;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepetidas;
    }
}