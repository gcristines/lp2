﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBrancos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int numBrancos = 0;

            while (contador < rchtxtTexto.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtTexto.Text[contador]))
                    numBrancos += 1;
                contador++;
            }
            MessageBox.Show("Número de caracteres em branco: " + numBrancos);
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int letrasR = 0;

            foreach (char c in rchtxtTexto.Text)
            {
                if (Char.ToUpper(c) == 'R')
                    letrasR += 1;
            }
            MessageBox.Show("O número de letras R é: " + letrasR);
        }

        private void btnRepetidas_Click(object sender, EventArgs e)
        {
            int letrasRepetidas = 0;
            string auxiliar = rchtxtTexto.Text.Replace(" ", "");

            for (int i = 1; i < auxiliar.Length; i++)
            {
                if (auxiliar[i] == auxiliar[i - 1])
                    letrasRepetidas += 1;
            }
            MessageBox.Show("Pares de letras repetidas: " + letrasRepetidas);
        }
    }
}
