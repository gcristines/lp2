﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            double A = 0, B = 0, C = 0, D = 0, salarioBruto = 0, totalGratificacao = 0;
            int producao = 0;

            if (!double.TryParse(txtSalario.Text, out A) || A < 0)
                MessageBox.Show("Salário inválido!");

            if (!double.TryParse(txtGratificacao.Text, out totalGratificacao) || totalGratificacao < 0)
                MessageBox.Show("Gratificação inválida!");

            if (!int.TryParse(txtProducao.Text, out producao))
                MessageBox.Show("Produção inválida!");

            else
            {
                if (producao < 100)
                {
                    B = 0;
                    C = 0;
                    D = 0;
                    salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totalGratificacao;
                }

                else if (producao == 100)
                {
                    B = 1;
                    C = 0;
                    D = 0;
                    salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totalGratificacao;
                }

                else if (producao > 100 && producao <= 120)
                {
                    B = 1;
                    C = 1;
                    D = 0;
                    salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totalGratificacao;
                }

                else if(producao > 120 && producao <= 150)
                {
                    B = 1;
                    C = 1;
                    D = 1;
                    salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totalGratificacao;
                }

                else
                {
                    B = 1;
                    C = 1;
                    D = 1;
                    salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totalGratificacao;
                }
            }

            if (salarioBruto <= 7000)
                MessageBox.Show("O(a) funcionário(a)" + " " + txtNome.Text + " " + "no cargo de" + " " + txtCargo.Text + " " + "e matrícula" + " " + txtMatricula.Text + "," + " " + "receberá um salário bruto de: " + salarioBruto.ToString("C2") + ".");

            else if (salarioBruto > 7000 && producao < 150 || totalGratificacao == 0)
                MessageBox.Show("Salário bruto não poderá ser pago.");

            else if (salarioBruto > 7000 && producao >= 150 && totalGratificacao > 0)
                MessageBox.Show("O(a) funcionário(a)" + " " + txtNome.Text + " " + "no cargo de" + " " + txtCargo.Text + " " + "e matrícula" + " " + txtMatricula.Text + "," + " " + "receberá um salário bruto de: " + salarioBruto.ToString("C2") + ".");
        }
    }
}