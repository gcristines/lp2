﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int i = 0;
            string str = txtPalindromo.Text.ToUpper();
            string invertida = "", brancos = "";

            while (i < str.Length)
            {
                if (Char.IsWhiteSpace(str, i))
                {
                    brancos = str.Replace(" ", "");

                    char[] arr = brancos.ToCharArray();
                    Array.Reverse(arr);

                    foreach (char chara in arr)
                    {
                        invertida = invertida + chara;
                    }

                    if (brancos == invertida)
                    {
                        MessageBox.Show("A frase: " + invertida + " é um palíndromo!");
                        break;
                    }
                    else
                    {
                        MessageBox.Show("A frase: " + str.ToUpper() + " não é um palíndromo!");
                        break;
                    }
                }
                i++;
            }
        }
    }
}