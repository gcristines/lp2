﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            int numeroH;
            double divideH, somaH = 0;
            string totalH;
            
            if (!int.TryParse(txtNumeroH.Text, out numeroH) || numeroH <= 0)
            {
                MessageBox.Show("Número H é inválido!");
                txtNumeroH.Focus();
            }

            else
            {
                for(var x = 1; x <= numeroH; x++)
                {
                    divideH = Math.Pow(x,-1);
                    somaH = somaH + divideH;
                }
                totalH = somaH.ToString("N2");
                MessageBox.Show("O número H é: " + totalH);
            }
        }
    }
}
