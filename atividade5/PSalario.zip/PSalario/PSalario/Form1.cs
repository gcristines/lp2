﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxNumeroFilhos.SelectedIndex = 1;
        }

        private void txtNomeFuncionario_Validated(object sender, EventArgs e)
        {
            if (txtNomeFuncionario.Text.Length == 0)
            {
                MessageBox.Show("Nome do funcionário está vazio!");
                txtNomeFuncionario.Focus();
            }
        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
            double salarioBruto;
            if (!double.TryParse(mskbxSalarioBruto.Text, out salarioBruto) || mskbxSalarioBruto.Text.Length == 0)
            {
                MessageBox.Show("Salário bruto é inválido!");
                mskbxSalarioBruto.Focus();
            }
        }

        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            double salarioBruto, descontoINSS, descontoIRPF, salarioFamilia, salarioLiquido;
            string aliquotaINSS, aliquotaIRPF;
            if (rbtnFeminino.Checked)
            {
                if (ckbxCasado.Checked)
                {
                    lblDados.Text = "Os descontos do salário da Sra." + txtNomeFuncionario.Text + " que é Casada e tem " + cbxNumeroFilhos.Text + " filho(s) são:";
                }
                else
                {
                    lblDados.Text = "Os descontos do salário da Sra." + txtNomeFuncionario.Text + " que é Solteira e tem " + cbxNumeroFilhos.Text + " filho(s) são:";
                }
            }
            else
            {
                if (ckbxCasado.Checked)
                {
                    lblDados.Text = "Os descontos do salário do Sr." + txtNomeFuncionario.Text + " que é Casado e tem " + cbxNumeroFilhos.Text + " filho(s) são:";
                }
                else
                {
                    lblDados.Text = "Os descontos do salário do Sr." + txtNomeFuncionario.Text + " que é Solteiro e tem " + cbxNumeroFilhos.Text + " filho(s) são:";
                }
            }

            if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto) && mskbxSalarioBruto.Text.Length > 0)
            {
                if (salarioBruto <= 800.47)
                {
                    aliquotaINSS = "7.65%";
                    txtAliquotaINSS.Text = aliquotaINSS.ToString();

                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    aliquotaIRPF = "0%";
                    txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                    descontoIRPF = 0;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

                    if(salarioBruto <= 435.52)
                    {
                        salarioFamilia = 22.33 * cbxNumeroFilhos.SelectedIndex;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }
                    else if(salarioBruto <= 654.61)
                    {
                        salarioFamilia = 15.74 * cbxNumeroFilhos.SelectedIndex;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }
                    else
                    {
                        salarioFamilia = 0 * cbxNumeroFilhos.SelectedIndex;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }

                else if(salarioBruto <= 1050)
                {
                    aliquotaINSS = "8.65%";
                    txtAliquotaINSS.Text = aliquotaINSS.ToString();

                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    aliquotaIRPF = "0%";
                    txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                    descontoIRPF = 0;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

                    salarioFamilia = 0 * cbxNumeroFilhos.SelectedIndex;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }

                else if (salarioBruto <= 1400.77)
                {
                    aliquotaINSS = "9.00%";
                    txtAliquotaINSS.Text = aliquotaINSS.ToString();

                    descontoINSS = 0.09 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    if(salarioBruto <= 1257.12)
                    {
                        aliquotaIRPF = "0%";
                        txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                        descontoIRPF = 0;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                    }
                    else
                    {
                        aliquotaIRPF = "15%";
                        txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                        descontoIRPF = 0.15 * salarioBruto;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                    }

                    salarioFamilia = 0 * cbxNumeroFilhos.SelectedIndex;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }
                    
                else if (salarioBruto <= 2801.56)
                {
                    aliquotaINSS = "11.00%";
                    txtAliquotaINSS.Text = aliquotaINSS.ToString();

                    descontoINSS = 0.011 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    if(salarioBruto <= 2512.08)
                    {
                        aliquotaIRPF = "15%";
                        txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                        descontoIRPF = 0.15 * salarioBruto;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                    }
                    else
                    {
                        aliquotaIRPF = "27.50%";
                        txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                        descontoIRPF = 0.275 * salarioBruto;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                    }

                    salarioFamilia = 0 * cbxNumeroFilhos.SelectedIndex;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }

                else
                {
                    aliquotaINSS = "-";
                    txtAliquotaINSS.Text = aliquotaINSS.ToString();

                    descontoINSS = 308.17;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    aliquotaIRPF = "27.50%";
                    txtAliquotaIRPF.Text = aliquotaIRPF.ToString();

                    descontoIRPF = 0.275 * salarioBruto;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

                    salarioFamilia = 0 * cbxNumeroFilhos.SelectedIndex;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");
                }
            }     
        }
    }
}
