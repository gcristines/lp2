﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PAtividade9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList()
                             {
                                "Ana",
                                "André",
                                "Débora",
                                "Fátima",
                                "João",
                                "Janete",
                                "Otávio",
                                "Marcelo",
                                "Pedro",
                                "Thais",
                             };

            alunos.RemoveAt(6);
            
            foreach (var item in alunos)
            {
                lstAlunos.Items.Add(item);
            }
        }
    }
}
