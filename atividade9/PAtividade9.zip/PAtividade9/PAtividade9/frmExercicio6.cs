﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int tamanho = 0;
            int[] auxiliar = new int[9];
            string[] nome = new string[9];
            string semBrancos = "";

            for (var x = 0; x < 9; x++)
            {
                nome[x] = Interaction.InputBox("Informe o nome da " + (x + 1) + "ª" + " pessoa:", "Entrada de Dados");

                if (nome[x] == "" || nome[x] == " ")
                {
                    MessageBox.Show("Nome inválido!");
                    x -= 1;
                }

                else if (Char.IsWhiteSpace(nome.ToString(), x))
                {
                    semBrancos = nome.ToString().Replace(" ", "");
                    tamanho = semBrancos.Length;
                    auxiliar[x] = tamanho;
                }

                else
                {
                    tamanho = nome[x].Length;
                    auxiliar[x] = tamanho;
                }

                lstNomes.Items.Add("O nome: " + nome[x] + " tem " + auxiliar[x] + " caracteres.");
            }
        }
    }
}
