﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAtividade9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            double[] media = new double[20];
            double calculoMedia = 0, soma = 0;
            string auxiliar;

            for (var l = 0; l < 20; l++)
            {
                soma = 0;
                calculoMedia = 0;

                for (var c = 0; c < 3; c++)
                {
                    auxiliar = Interaction.InputBox("Informe a nota " + (c + 1) + " do aluno " + (l + 1) + ":", "Entrada de Dados");
                    
                    if (!double.TryParse(auxiliar, out notas[l,c]))
                    {
                        MessageBox.Show("Nota inválida!");
                        c -= 1;
                    }

                    else if (notas[l,c] < 0 || notas[l,c] > 10)
                    {
                        MessageBox.Show("Nota inválida!");
                        c -= 1;
                    }

                    else
                        soma = soma + notas[l,c];
                }
                calculoMedia = soma / 3;
                media[l] = calculoMedia;
                lstMedia.Items.Add("Aluno " + (l + 1) + ": " + "média " + media[l].ToString("N2"));
            }
        }
    }
}
