﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAtividade9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[10];
            double[] preco = new double[10];
            double faturamento = 0;
            string auxiliar;

            for (var x = 0; x < 10; x++)
            {
                auxiliar = Interaction.InputBox("Informe a quantidade da mercadoria " + (x + 1) + ":", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out quantidade[x]) || quantidade[x] <= 0)
                {
                    MessageBox.Show("Quantidade inválida!");
                    x -= 1;
                }

                else
                {
                    do
                    {
                        auxiliar = Interaction.InputBox("Informe o preço da mercadoria " + (x + 1) + ":", "Entrada de Dados");

                        if (!double.TryParse(auxiliar, out preco[x]) || preco[x] <= 0)
                            MessageBox.Show("Preço inválido!");

                        else
                            faturamento = faturamento + (quantidade[x] * preco[x]);

                    } while (preco[x] <= 0);
                }    
            }
            MessageBox.Show("O faturamento é: " + faturamento.ToString("C2"));
        }
    }
}
