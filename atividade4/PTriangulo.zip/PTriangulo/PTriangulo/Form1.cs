﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            double ladoA;
            if (!double.TryParse(textBox1.Text, out ladoA) || textBox1.Text.Length == 0)
            {
                MessageBox.Show("Lado A: número inválido ou campo vazio!");
                textBox1.Focus();
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            double ladoB;
            if (!double.TryParse(textBox2.Text, out ladoB) || textBox2.Text.Length == 0)
            {
                MessageBox.Show("Lado B: número inválido ou campo vazio!");
                textBox2.Focus();
            }
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            double ladoC;
            if (!double.TryParse(textBox3.Text, out ladoC) || textBox3.Text.Length == 0)
            {
                MessageBox.Show("Lado C: número inválido ou campo vazio!");
                textBox3.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;
            if ((double.TryParse(textBox1.Text, out ladoA) && textBox1.Text.Length > 0) && 
                (double.TryParse(textBox2.Text, out ladoB) && textBox2.Text.Length > 0) && 
                (double.TryParse(textBox3.Text, out ladoC) && textBox3.Text.Length > 0))
            {

                if ((ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC)) &&
                    (ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC)) &&
                    (ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB)))
                {
                    if (ladoA == ladoB && ladoA == ladoC && ladoC == ladoB)
                    {
                        MessageBox.Show("Triângulo equilátero!");
                    }
                    else if (ladoA != ladoB && ladoA != ladoC && ladoC != ladoB)
                    {
                        MessageBox.Show("Triângulo escaleno!");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo isósceles!");
                    }
                }
                else
                {
                    MessageBox.Show("Os valores fornecidos não pertencem aos lados de um triângulo!");
                }
            }
            else
            {
                MessageBox.Show("Os números informados são inválidos ou os campos estão vazios!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
