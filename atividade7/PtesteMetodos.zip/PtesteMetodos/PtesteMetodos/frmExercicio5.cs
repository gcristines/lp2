﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            int numero1;

            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número 1 é inválido!");
                txtNumero1.Focus();
            }
            else
            {
                if (numero1 < 0)
                {
                    MessageBox.Show("Número 1 não pode ser menor que zero!");
                    txtNumero1.Focus();
                }
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            int numero2;

            if (!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 é inválido!");
                txtNumero2.Focus();
            }
            else
            {
                if (numero2 < 0)
                {
                    MessageBox.Show("Número 2 não pode ser menor que zero!");
                    txtNumero2.Focus();
                }
            }
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1, numero2, sorteio;
            string resultado;

            Random rnd = new Random();

            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("O número 1 é inválido!");
                txtNumero1.Focus();
            }
            else if (numero1 < 0)
            {
                MessageBox.Show("O número 1 não pode ser menor que zero!");
                txtNumero1.Focus();
            }

            else if (!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("O número 2 é inválido!");
                txtNumero2.Focus();
            }
            else if (numero2 < 0)
            {
                MessageBox.Show("O número 2 não pode ser menor que zero!");
                txtNumero2.Focus();
            }
            else if (numero2 < numero1)
            {
                MessageBox.Show("O número 2 não pode ser menor que o número 1!");
                txtNumero2.Focus();
            }
            else
            {
                sorteio = rnd.Next(numero1, numero2);
                resultado = Convert.ToString(sorteio);
                MessageBox.Show(resultado);
            } 
        }
    }
}
