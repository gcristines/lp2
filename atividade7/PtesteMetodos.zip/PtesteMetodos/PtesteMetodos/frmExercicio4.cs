﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumericos_Click(object sender, EventArgs e)
        {
            string str = richTextBox1.Text;
            int i, quantidade = 0;

            for (i = 0; i<str.Length; i++)
            {
                if(Char.IsNumber(str, i))
                {
                    quantidade++;
                }
            }
            str = Convert.ToString(quantidade);
            MessageBox.Show(str);
        }

        private void btnBrancos_Click(object sender, EventArgs e)
        {
            string str = richTextBox1.Text;
            int i = 0, posicao = 0;

            while (i < str.Length)
            {
                if (Char.IsWhiteSpace(str, i))
                {
                    posicao = i;
                    break;
                }
                i++;
            }
            str = Convert.ToString(posicao);
            MessageBox.Show(str);
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int i = 0, quantidade = 0;
            string str = richTextBox1.Text;
            char[] arr = str.ToCharArray();         // jogo a string para um array

            foreach (char chara in arr)
            {
                if(Char.IsLetter(str, i))
                {
                    quantidade++;
                }
                i++;
            }
            str = Convert.ToString(quantidade);
            MessageBox.Show(str);
        }
    }
}
